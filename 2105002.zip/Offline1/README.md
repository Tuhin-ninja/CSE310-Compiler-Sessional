to execute run this : g++ -std=c++17 2105002_main.cpp -o main

to generate report run this : g++ -std=c++17 2105002_report_generator.cpp -o report